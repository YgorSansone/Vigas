var ar
var bar

function setup() {
  var canvas =  createCanvas(400, 200);
  ar = []
  bar = 30
  canvas.parent('sketch-holder');
  createP('Tamanho da Barra:')
  let tamanho = createInput(bar,'number')
  createP('Número de Forças:')
  let inp = createInput('','number');
  inp.input(setNumberofForces);
  tamanho.input(setBarSize)
  createP()
}

function setBarSize() {
  bar = parseInt(this.value())
}

function limeteBar(){
  if(this.value()<0){
    this.value(0);
  }
}
function limitIntensidade() {
  if(this.value()<0){
    this.value(0);
  }
}

function limitAngulo() {
  var v = this.value()
  if(v < 0){
    v=0
  }
  while(v > 360){
    v -= 360
  }
  this.value(v)
}

function limitPosicao() {
  var v = this.value()
  console.log(v)
  if (v > bar){
    this.value(bar)
  }else{
    if(v < 0){
      this.value(0)
    }else if(v[0] == 0 && v.length > 1){
      this.value(v[1])
    }
  }
}

function setNumberofForces() {
  let int = parseInt(this.value())
  while(ar.length > int){
    let temp = ar.pop()
    Object.values(temp).forEach(
      t => Object.values(t).forEach(
        a => a.remove()
      )
    )
  }

  for(var i = ar.length; i < int; i++){
    ar.push({
      id: {p:createDiv(i+1 +'º')},
      intensidade: {p:createP('Intensidade'), v:createInput('','number')},
      angulo: {p:createP('Angulo'), v:createInput('','number')},
      posicao: {p:createP('Posicao'), v:createInput('','number')},
      sentido: {p:createP('Sentido'), v:createCheckbox('Superior', true)}
    })
    ar[i].intensidade.v.input(limitIntensidade)
    ar[i].angulo.v.input(limitAngulo)
    ar[i].posicao.v.input(limitPosicao)
    ar[i].id.p.id(i)
    ar[i].id.p.class('elementos');
    var keys = Object.values(ar[i])
    keys.splice(0,1)
    console.log(keys)
    keys.forEach((k)=>{
      k.p.parent(ar[i].id.p)
      k.v.parent(ar[i].id.p)
    })

    createP()
  }
}


function scaleSize(pos, w){
  return w * pos/bar + 30
}

function scaleIntensity(arr, value){
  var intens = []
  arr.forEach(object => {
    intens.push(object.intensidade.v.value())
  })

  var max = Math.max(...intens)

  return 15 + 55*value/max

}

function draw() {
  background('#fffff');
  fill('#5d75cd');
  x = 10;
  w = 350;
  h = 30;
  rect(30, 100, w, h);
  triangle(10+x, 150, 20+x, 130, 30+x, 150);
  circle(w+x+15, 141, 20);
  ar.forEach(object => {
    drawArrow(scaleSize(object.posicao.v.value(),w), object.sentido.v.checked() ? 100 : 100 + h, object.sentido.v.checked() ? toRadians(object.angulo.v.value()) : toRadians(object.angulo.v.value()-180), scaleIntensity(ar, object.intensidade.v.value()))
  })

}

function toRadians(grades) {
  return TWO_PI*grades/360
}

function drawArrow(x1, y1, angle,N){
  size = N;
  t = 12;
  v = 5;
  
  x2 = size*cos(angle) + x1
  y2 = -size*sin(angle) + y1
  
  x3 = t*cos(angle) + x1
  y3 = -t*sin(angle) + y1
  
  _x1 = 5*cos(angle) + x1
  _y1 = -5*sin(angle) + y1
  
  x4 = v*cos(toRadians(90)-angle) + x3
  y4 = v*sin(toRadians(90)-angle) + y3
  
  x5 = -v*cos(toRadians(90)-angle) + x3
  y5 = -v*sin(toRadians(90)-angle) + y3
  
  strokeWeight(3);
  line(_x1, _y1, x2, y2);
  strokeWeight(1);
  triangle(x4,y4, x1, y1, x5, y5);
}
